# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(signal-handling src/signal-handling.cpp)
set_property(TARGET signal-handling PROPERTY CXX_STANDARD 11)
target_link_libraries(signal-handling lionss pthread)

add_executable(valgrind-massif src/valgrind-massif.cpp)
set_property(TARGET valgrind-massif PROPERTY CXX_STANDARD 11)
target_link_libraries(valgrind-massif lionss pthread)

add_executable(startup-latency src/startup-latency.cpp)
set_property(TARGET startup-latency PROPERTY CXX_STANDARD 11)
target_link_libraries(startup-latency lionss pthread)

add_executable(submodule-sync src/submodule-sync.cpp)
set_property(TARGET submodule-sync PROPERTY CXX_STANDARD 11)
target_link_libraries(submodule-sync lionss pthread)

add_executable(structure-aware-fuzz src/structure-aware-fuzz.cpp)
set_property(TARGET structure-aware-fuzz PROPERTY CXX_STANDARD 11)
target_link_libraries(structure-aware-fuzz lionss pthread)

add_executable(makefiles-build src/makefiles-build.cpp)
set_property(TARGET makefiles-build PROPERTY CXX_STANDARD 11)
target_link_libraries(makefiles-build lionss pthread)

add_executable(release-notes src/release-notes.cpp)
set_property(TARGET release-notes PROPERTY CXX_STANDARD 11)
target_link_libraries(release-notes lionss pthread)

add_executable(api-compat-check src/api-compat-check.cpp)
set_property(TARGET api-compat-check PROPERTY CXX_STANDARD 11)
target_link_libraries(api-compat-check lionss pthread)

add_executable(rocm-build src/rocm-build.cpp)
set_property(TARGET rocm-build PROPERTY CXX_STANDARD 11)
target_link_libraries(rocm-build lionss pthread)

add_executable(license-check src/license-check.cpp)
set_property(TARGET license-check PROPERTY CXX_STANDARD 11)
target_link_libraries(license-check lionss pthread)

add_executable(branch-prediction src/branch-prediction.cpp)
set_property(TARGET branch-prediction PROPERTY CXX_STANDARD 11)
target_link_libraries(branch-prediction lionss pthread)

add_executable(weekly-build src/weekly-build.cpp)
set_property(TARGET weekly-build PROPERTY CXX_STANDARD 11)
target_link_libraries(weekly-build lionss pthread)

add_executable(feature-flags-matrix src/feature-flags-matrix.cpp)
set_property(TARGET feature-flags-matrix PROPERTY CXX_STANDARD 11)
target_link_libraries(feature-flags-matrix lionss pthread)

add_executable(google-benchmark src/google-benchmark.cpp)
set_property(TARGET google-benchmark PROPERTY CXX_STANDARD 11)
target_link_libraries(google-benchmark lionss pthread)

add_executable(bazel-build src/bazel-build.cpp)
set_property(TARGET bazel-build PROPERTY CXX_STANDARD 11)
target_link_libraries(bazel-build lionss pthread)

add_executable(jumbo-build src/jumbo-build.cpp)
set_property(TARGET jumbo-build PROPERTY CXX_STANDARD 11)
target_link_libraries(jumbo-build lionss pthread)

add_executable(package-msi src/package-msi.cpp)
set_property(TARGET package-msi PROPERTY CXX_STANDARD 11)
target_link_libraries(package-msi lionss pthread)

add_executable(vulnerability-report src/vulnerability-report.cpp)
set_property(TARGET vulnerability-report PROPERTY CXX_STANDARD 11)
target_link_libraries(vulnerability-report lionss pthread)

add_executable(clang-analyzer src/clang-analyzer.cpp)
set_property(TARGET clang-analyzer PROPERTY CXX_STANDARD 11)
target_link_libraries(clang-analyzer lionss pthread)

add_executable(conformance-suite src/conformance-suite.cpp)
set_property(TARGET conformance-suite PROPERTY CXX_STANDARD 11)
target_link_libraries(conformance-suite lionss pthread)

add_executable(gcc-14 src/gcc-14.cpp)
set_property(TARGET gcc-14 PROPERTY CXX_STANDARD 11)
target_link_libraries(gcc-14 lionss pthread)

add_executable(control-flow-integrity src/control-flow-integrity.cpp)
set_property(TARGET control-flow-integrity PROPERTY CXX_STANDARD 11)
target_link_libraries(control-flow-integrity lionss pthread)

add_executable(mutmut-run src/mutmut-run.cpp)
set_property(TARGET mutmut-run PROPERTY CXX_STANDARD 11)
target_link_libraries(mutmut-run lionss pthread)

add_executable(strip-check src/strip-check.cpp)
set_property(TARGET strip-check PROPERTY CXX_STANDARD 11)
target_link_libraries(strip-check lionss pthread)

add_executable(acceptance-tests src/acceptance-tests.cpp)
set_property(TARGET acceptance-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(acceptance-tests lionss pthread)

add_executable(contention-bench src/contention-bench.cpp)
set_property(TARGET contention-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(contention-bench lionss pthread)

add_executable(build-release src/build-release.cpp)
set_property(TARGET build-release PROPERTY CXX_STANDARD 11)
target_link_libraries(build-release lionss pthread)

add_executable(fortify-source src/fortify-source.cpp)
set_property(TARGET fortify-source PROPERTY CXX_STANDARD 11)
target_link_libraries(fortify-source lionss pthread)

add_executable(sandbox-build src/sandbox-build.cpp)
set_property(TARGET sandbox-build PROPERTY CXX_STANDARD 11)
target_link_libraries(sandbox-build lionss pthread)

add_executable(lcov-report src/lcov-report.cpp)
set_property(TARGET lcov-report PROPERTY CXX_STANDARD 11)
target_link_libraries(lcov-report lionss pthread)

