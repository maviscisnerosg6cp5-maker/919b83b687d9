// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("acceptance tests\n", stdout);
  return lionss_run_workload("acceptance-tests");
}
